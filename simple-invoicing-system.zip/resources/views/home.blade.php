@extends('layout.base')

@section('content')
    <h1>Homepage</h1>
    <section>
        <header>

        </header>
    </section>
@endsection
