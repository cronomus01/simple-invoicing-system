<?php $__env->startSection('content'); ?>
    <div>
        <div class="flex justify-between">
            <h1 class="text-lg">Invoices</h1>
            <a href="/invoices/create" class="text-blue-600">Create Invoice</a>
        </div>
        <table class="table-auto mt-5">
            <thead>
                <th>Type</th>
                <th>Product / Service</th>
                <th>Quantity</th>
                <th>Base Price</th>
                <th>Subtotal</th>
                <th>Action</th>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($invoice->type); ?></td>
                        <td><?php echo e($invoice->produce_service); ?></td>
                        <td><?php echo e($invoice->quantity); ?></td>
                        <td><?php echo e($invoice->base_price); ?></td>
                        <td><?php echo e($invoice->subtotal); ?></td>
                        <td class="flex items-center space-x-4">
                            <a href="/invoices/edit/<?php echo e($invoice->id); ?>" class="text-green-500">Edit</a>
                            <form action="/invoices/delete/<?php echo e($invoice->id); ?>" method="post">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="text-rose-500">Delete</button>
                            </form>
                            <a href="/payment/show/<?php echo e($invoice->id); ?>" class="text-violet-500">Payment</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simple-invoicing-system\resources\views/invoice.blade.php ENDPATH**/ ?>