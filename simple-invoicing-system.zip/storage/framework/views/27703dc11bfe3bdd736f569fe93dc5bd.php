<?php $__env->startSection('content'); ?>
    <?php if(isset($invoice)): ?>
        <form action="/invoices/update/<?php echo e($invoice->id); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            
            <div class="flex justify-between">
                <label for="">Type:</label>
                <select name="type">
                    <option value="proforma">Proforma</option>
                    <option value="sales">Sales</option>
                </select>
            </div>
            <div class="flex justify-between">
                <label for="">Product Service:</label>
                <input type="text" placeholder="Enter product or service" name="product_service"
                    value=<?php echo e($invoice->product_service); ?>>
            </div>
            <div class="flex justify-between">
                <label for="">Quantity:</label>
                <input type="number" name="quantity" value=<?php echo e($invoice->quantity); ?>>
            </div>
            <div class="flex justify-between">
                <label for="">Base Price:</label>
                <input type="number" name="base_price" value=<?php echo e($invoice->base_price); ?>>
            </div>
            <button type="submit" class="px-2 py-1 border rounded mt-2 bg-violet-600 text-white">Update</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simple-invoicing-system\resources\views/invoices/invoice-edit.blade.php ENDPATH**/ ?>