<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <main>
        <a href="/login">
            <button>Login</button>
        </a>
    </main>
</body>

</html>
<?php /**PATH C:\laragon\www\simple-invoicing-system\resources\views/welcome.blade.php ENDPATH**/ ?>