<?php $__env->startSection('content'); ?>
    <h1>Homepage</h1>
    <section>
        <header>

        </header>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simple-invoicing-system\resources\views/home.blade.php ENDPATH**/ ?>